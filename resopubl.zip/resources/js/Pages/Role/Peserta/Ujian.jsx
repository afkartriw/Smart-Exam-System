import Navbar from "@/Components/Lembaga/Navbar";
import { useState, useEffect } from "react";
import Swal from "sweetalert2";

export default function Page() {
    const [timeLeft, setTimeLeft] = useState(2237); // dalam detik (37 menit 17 detik)

    useEffect(() => {
        const timer = setInterval(() => {
            setTimeLeft((prev) => (prev > 0 ? prev - 1 : 0));
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const formatTime = (time) => {
        const hours = Math.floor(time / 3600);
        const minutes = Math.floor((time % 3600) / 60);
        const seconds = time % 60;

        return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(
            2,
            "0"
        )}:${String(seconds).padStart(2, "0")}`;
    };

    const handleFinishExam = () => {
        Swal.fire({
            title: "Apakah Anda yakin?",
            text: `Anda akan menyelesaikan ujian dengan sisa waktu ${formatTime(
                timeLeft
            )}.`,
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ya, selesaikan!",
            cancelButtonText: "Batal",
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire(
                    "Selesai!",
                    "Ujian telah diselesaikan.",
                    "success"
                ).then(() => {
                    // Redirect atau lakukan sesuatu setelah ujian selesai
                    window.location.href = "/peserta"; // Contoh redirect
                });
            }
        });
    };

    return (
        <div className="min-h-screen bg-gray-100">
            {/* Header */}
            <Navbar />

            {/* Main Content */}
            <div className="max-w-full mx-auto p-6 pt-20">
                {/* Main Section */}
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                    {/* Question Section */}
                    <div className="col-span-3 bg-white rounded shadow p-4">
                        <div>
                            <h3 className="text-lg font-semibold mb-2">
                                Soal No #3
                            </h3>
                            <p className="mb-4">
                                Manakah yang tidak termasuk dalam peralatan
                                pendukung kendaraan beroda dua?
                            </p>

                            <div className="space-y-4">
                                {[
                                    "Helm yang berstandar SNI",
                                    "Rompi pemantul cahaya",
                                    "Sepatu yang menutup tumit",
                                    "Kacamata hitam",
                                ].map((option, index) => (
                                    <label
                                        key={index}
                                        className="block p-4 border rounded cursor-pointer hover:bg-gray-100"
                                    >
                                        <input
                                            type="radio"
                                            name="question"
                                            className="mr-2"
                                            value={option}
                                        />
                                        {String.fromCharCode(65 + index)}.{" "}
                                        {option}
                                    </label>
                                ))}
                            </div>

                            <div className="flex justify-between mt-6">
                                <button className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">
                                    Sebelumnya
                                </button>
                                <label className="flex items-center px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600 cursor-pointer">
                                    <input
                                        type="checkbox"
                                        className="mr-2"
                                        onChange={(e) => {
                                            // Handle logic ketika checkbox di-centang/un-centang
                                            console.log(
                                                "Ragu-ragu:",
                                                e.target.checked
                                            );
                                        }}
                                    />
                                    Ragu-ragu
                                </label>
                                <button className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">
                                    Selanjutnya
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* Sidebar */}
                    <aside className="bg-white rounded shadow p-4">
                        <div>
                            <h2 className="text-center text-3xl font-bold text-gray-700 mb-2">
                                {formatTime(timeLeft)}
                            </h2>
                            <div className="flex justify-center gap-2 text-sm text-gray-600">
                                <span>hours</span>
                                <span>minutes</span>
                                <span>seconds</span>
                            </div>
                        </div>
                        <div className="mt-6">
                            <button
                                className="w-full bg-red-500 text-white py-2 rounded mb-2 hover:bg-red-600"
                                onClick={handleFinishExam}
                            >
                                Selesai
                            </button>
                        </div>
                        <div className="mt-4 grid grid-cols-5 gap-1">
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((number) => (
                                <button
                                    key={number}
                                    className={`w-12 h-12 rounded-full ${
                                        number === 3
                                            ? "bg-blue-500 text-white"
                                            : "bg-gray-200 text-gray-700"
                                    }`}
                                >
                                    {String(number).padStart(2, "0")}
                                </button>
                            ))}
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    );
}
