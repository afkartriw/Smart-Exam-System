import Navbar from "@/Components/Lembaga/Navbar";
import React from "react";

const Peserta = () => {
    return (
        <>
            <Navbar />
            <div className="bg-gray-100 mt-16">
                <main className="p-8">
                    <div className="bg-blue-100 text-blue-800 p-4 rounded mb-6">
                        <p>Informasi</p>
                        <p>
                            Berikut ini ditampilkan daftar sesi ujian untuk
                            Anda, diurutkan berdasarkan waktu.
                        </p>
                    </div>

                    <h2 className="p-3 text-center border-b border-gray-400 text-2xl font-semibold my-4">
                        Ujian yang akan datang
                    </h2>

                    {/* Uji Kompetensi #2 */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="border p-4 rounded shadow-sm bg-white">
                            <h3 className="font-semibold">Uji Kompetensi #2</h3>
                            <p className="text-blue-600 font-medium">
                                Bahasa Indonesia
                            </p>
                            <p>Mulai: Kamis, 29 Jul 2021 23:45:00</p>
                            <p>Sifat: Serentak</p>
                            <p>Durasi: 20 menit</p>
                            <p>Batas: Jumat, 30 Jul 2021 00:05:00</p>
                            <div className="mt-4 flex items-center">
                                <span className="text-gray-500 mr-2">N.A</span>
                                <a
                                    href="/peserta/detail"
                                    className="bg-blue-500 text-white px-3 py-1 rounded"
                                >
                                    Mulai
                                </a>
                            </div>{" "}
                        </div>
                    </div>

                    <h2 className="p-3 text-center border-b border-gray-400 text-2xl font-semibold my-4">
                        Histori Ujian
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Uji Kompetensi #1 */}
                        <div className="border p-4 rounded shadow-sm bg-white">
                            <h3 className="font-semibold">Uji Kompetensi #1</h3>
                            <p className="text-blue-600 font-medium">
                                Bahasa Indonesia
                            </p>
                            <p>Mulai: Senin, 02 Agt 2021 17:45:00</p>
                            <p>Sifat: Serentak</p>
                            <p>Durasi: 120 menit</p>
                            <p>Batas: Senin, 02 Agt 2021 19:45:00</p>
                            <div className="mt-4 flex items-center">
                                <span className="text-4xl font-bold mr-2">
                                    80
                                </span>
                                <button className="bg-green-500 text-white px-3 py-1 rounded">
                                    Hasil
                                </button>
                            </div>
                        </div>
                        <div className="border p-4 rounded shadow-sm bg-white">
                            <h3 className="font-semibold">Uji Kompetensi #1</h3>
                            <p className="text-blue-600 font-medium">
                                Bahasa Indonesia
                            </p>
                            <p>Mulai: Senin, 02 Agt 2021 17:45:00</p>
                            <p>Sifat: Serentak</p>
                            <p>Durasi: 120 menit</p>
                            <p>Batas: Senin, 02 Agt 2021 19:45:00</p>
                            <div className="mt-4 flex items-center">
                                <span className="text-4xl font-bold mr-2">
                                    80
                                </span>
                                <button className="bg-green-500 text-white px-3 py-1 rounded">
                                    Hasil
                                </button>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </>
    );
};

export default Peserta;
