import Navbar from "@/Components/Lembaga/Navbar";
import React from "react";

import { useEffect, useState } from "react";

const Detail = () => {
    const [timeLeft, setTimeLeft] = useState(7200); // 120 menit dalam detik

    useEffect(() => {
        const timer = setInterval(() => {
            setTimeLeft((prevTime) => (prevTime > 0 ? prevTime - 1 : 0));
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const formatTime = (time) => {
        const minutes = Math.floor(time / 60);
        const seconds = time % 60;
        return `${String(minutes).padStart(2, "0")}:${String(seconds).padStart(
            2,
            "0"
        )}`;
    };
    return (
        <>
            <Navbar />
            <div className="min-h-screen bg-gray-100 p-4 pt-28">
                <div className="max-w-xl mx-auto bg-white rounded-lg shadow-md p-6">
                    <h2 className="text-center text-lg font-semibold text-gray-700">
                        IKATAN MOTOR INDONESIA
                    </h2>
                    <h1 className="text-center text-2xl font-bold mt-2 text-gray-900">
                        BALAP MOBIL
                    </h1>
                    <p className="text-center text-sm text-gray-500 mt-1">
                        NO-GRUP - Umum
                    </p>

                    <div className="mt-4 text-center">
                        <p className="text-gray-600">
                            Waktu Pengerjaan:{" "}
                            <span className="font-medium">120 menit</span>
                        </p>
                        <p className="text-gray-600">
                            Jumlah Soal:{" "}
                            <span className="font-medium">7 butir</span>
                        </p>
                    </div>

                    <p className="mt-6 text-center text-red-600 font-medium">
                        Sesi tes sudah dimulai. Sisa waktu tes:
                    </p>

                    <div className="text-center mt-4">
                        <p className="text-2xl font-bold text-gray-800">
                            {formatTime(timeLeft)}
                        </p>
                        <div className="text-sm text-gray-600 flex justify-center gap-2">
                            <span>minutes</span>
                            <span>seconds</span>
                        </div>
                    </div>

                    <div className="mt-6 text-center space-x-2">
                        <a
                            href="/peserta"
                            className="px-4 py-2 bg-red-500 text-white font-medium rounded-lg shadow hover:bg-red-600"
                        >
                            Kembali
                        </a>
                        <a
                            href="/peserta/ujian"
                            className="px-4 py-2 bg-blue-500 text-white font-medium rounded-lg shadow hover:bg-blue-600"
                        >
                            Kerjakan
                        </a>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Detail;
