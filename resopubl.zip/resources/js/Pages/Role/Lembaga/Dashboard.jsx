import Navbar from "@/Components/Lembaga/Navbar";
import Sidebar from "@/components/lembaga/Sidebar"; // Impor komponen Sidebar
import React, { useState } from "react";

export default function Page() {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    return (
        <>
            <div className="relative flex h-screen">
                {/* Sidebar */}
                <Sidebar
                    isSidebarOpen={isSidebarOpen}
                    toggleSidebar={toggleSidebar}
                />

                {/* Content Wrapper */}
                <div
                    className={`flex-1 flex flex-col ${
                        isSidebarOpen ? "ml-56" : "ml-16"
                    } transition-all duration-300`}
                >
                    {/* Navbar */}
                    <Navbar toggleSidebar={toggleSidebar} />

                    {/* Main Content */}
                    <main className="flex-1 bg-gray-100 pt-16">
                        {/* Dashboard Stats */}
                        <div className="container mx-auto mt-6 px-4">
                            <h2 className="text-xl font-semibold mb-4">
                                DASHBOARD APPLICATION
                            </h2>
                            <div className="grid grid-cols-4 gap-4">
                                <div className="bg-white shadow rounded-lg p-6 text-center">
                                    <p className="text-2xl font-bold">0</p>
                                    <p className="text-sm text-gray-600">
                                        Paket Soal
                                    </p>
                                </div>
                                <div className="bg-white shadow rounded-lg p-6 text-center">
                                    <p className="text-2xl font-bold">0</p>
                                    <p className="text-sm text-gray-600">
                                        Peserta Ujian
                                    </p>
                                </div>
                                <div className="bg-white shadow rounded-lg p-6 text-center">
                                    <p className="text-2xl font-bold">50</p>
                                    <p className="text-sm text-gray-600">
                                        Sisa Poin
                                    </p>
                                </div>
                                <div className="bg-white shadow rounded-lg p-6 text-center">
                                    <p className="text-2xl font-bold">4</p>
                                    <p className="text-sm text-gray-600">
                                        Total User Online
                                    </p>
                                </div>
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </>
    );
}
