import React, { useState } from "react";
import { Link, usePage } from "@inertiajs/react"; // Impor usePage dan Link
import Navbar from "@/Components/Lembaga/Navbar";
import { FaFileExport } from "react-icons/fa";

export default function TambahPeserta() {
    const { props } = usePage(); // Akses data halaman melalui usePage
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        permissions: [],
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handlePermissionChange = (permission) => {
        setFormData((prevData) => ({
            ...prevData,
            permissions: prevData.permissions.includes(permission)
                ? prevData.permissions.filter((p) => p !== permission)
                : [...prevData.permissions, permission],
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Kirim data ke backend menggunakan Inertia.post
        Inertia.post("/peserta/tambah", formData, {
            onSuccess: () => {
                // Redirect ke halaman data peserta setelah berhasil
                Inertia.visit("/data-peserta");
            },
        });
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Navbar />
            {/* Main Content */}
            <main className="max-w-3xl m-auto pt-20">
                <div
                    onSubmit={handleSubmit}
                    className="bg-white p-6 rounded-lg shadow-md"
                >
                    <h1 className="text-2xl font-bold mb-4">TAMBAH SOAL</h1>{" "}
                    <div className="flex space-x-4">
                        <a
                            href="/lembaga/paketsoal/import"
                            className="flex items-center px-4 h-10 gap-2 bg-indigo-500 text-white hover:bg-indigo-700 rounded"
                        >
                            <FaFileExport /> Tambah Manual
                        </a>
                        <a
                            href="/lembaga/paketsoal/import"
                            className="flex items-center px-4 h-10 gap-2 bg-blue-500 text-white hover:bg-blue-700 rounded"
                        >
                            <FaFileExport /> Import Word
                        </a>
                        <a
                            href="/lembaga/paketsoal/import"
                            className="flex items-center px-4 h-10 gap-2 bg-green-500 text-white hover:bg-green-700 rounded"
                        >
                            <FaFileExport /> Import Exel
                        </a>
                    </div>
                </div>
                <form
                    onSubmit={handleSubmit}
                    className="bg-white p-6 rounded-lg shadow-md mt-10"
                >
                    {" "}
                    <h1 className="text-2xl font-bold mb-4">
                        TAMBAH PAKET SOAL
                    </h1>
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700">
                            Nama Paket Soal
                        </label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="mt-1 p-2 border rounded w-full"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700">
                            Materi
                        </label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="mt-1 p-2 border rounded w-full"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700">
                            Tanggal Dibuat (default sekarang)
                        </label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="mt-1 p-2 border rounded w-full"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700">
                            Dibuat Oleh (dibuat default)
                        </label>
                        <input
                            type="text"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            className="mt-1 p-2 border rounded w-full"
                            required
                        />
                    </div>
                    <div className="flex justify-between gap-2">
                        <a
                            href="/lembaga/paketsoal"
                            className="flex items-center px-4 py-2 gap-2 bg-gray-500 hover:bg-gray-700 text-white rounded"
                        >
                            Kembali
                        </a>
                        <button
                            type="submit"
                            className="flex items-center px-4 py-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                        >
                            Tambah Peserta
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}
