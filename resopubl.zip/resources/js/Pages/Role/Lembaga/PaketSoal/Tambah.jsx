import React, { useState } from "react";
import { Link, usePage } from "@inertiajs/react"; // Impor usePage, Link, dan Inertia
import { Inertia } from "@inertiajs/inertia"; // Import Inertia
import Navbar from "@/Components/Lembaga/Navbar";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import styles

export default function TambahPeserta() {
    const { props } = usePage(); // Akses data halaman melalui usePage
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        permissions: [],
        materi: "",
        acakSoal: "",
        acakJawaban: "",
        skalaNilai: 1,
        petunjukPengerjaan: "",
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSkalaNilaiChange = (e) => {
        const newSkala = parseInt(e.target.value);
        setFormData((prev) => ({
            ...prev,
            skalaNilai: newSkala,
            kkm: prev.kkm > newSkala ? 1 : prev.kkm, // Reset KKM jika lebih besar dari skala baru
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        Inertia.post("/peserta/tambah", formData, {
            onSuccess: () => {
                Inertia.visit("/data-peserta");
            },
        });
    };

    const handleQuillChange = (value) => {
        setFormData({
            ...formData,
            petunjukPengerjaan: value,
        });
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Navbar />
            {/* Main Content */}
            <main className="max-w-3xl m-auto pt-20">
                <div className="bg-white rounded-xl shadow-xl">
                    {" "}
                    <div className="px-6 p-3">
                        <h1 className="text-2xl font-bold text-blue-900">
                            TAMBAH PAKET SOAL
                        </h1>
                    </div>
                    <form onSubmit={handleSubmit} className="px-6 p-3 border-y">
                        {/* Grid Layout */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            {/* Nama Paket Soal */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Nama Paket Soal
                                </label>
                                <input
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Materi */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Materi
                                </label>
                                <input
                                    type="text"
                                    name="materi"
                                    value={formData.materi}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Skala Nilai */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Skala Nilai
                                </label>
                                <select
                                    name="skalaNilai"
                                    value={formData.skalaNilai}
                                    onChange={handleSkalaNilaiChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                >
                                    {[1, 4, 5, 10, 50, 100].map((value) => (
                                        <option key={value} value={value}>
                                            {value}
                                        </option>
                                    ))}
                                </select>
                            </div>

                            {/* KKM */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    KKM
                                </label>
                                <select
                                    name="kkm"
                                    value={formData.kkm}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                >
                                    {[...Array(formData.skalaNilai)].map(
                                        (_, i) => (
                                            <option key={i + 1} value={i + 1}>
                                                {i + 1}
                                            </option>
                                        )
                                    )}
                                </select>
                            </div>

                            {/* Acak Soal */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Acak Soal
                                </label>
                                <div className="flex items-center space-x-4">
                                    <label>
                                        <input
                                            type="radio"
                                            name="acakSoal"
                                            value="ya"
                                            checked={formData.acakSoal === "ya"}
                                            onChange={handleInputChange}
                                            className="mr-2"
                                        />
                                        Ya
                                    </label>
                                    <label>
                                        <input
                                            type="radio"
                                            name="acakSoal"
                                            value="tidak"
                                            checked={
                                                formData.acakSoal === "tidak"
                                            }
                                            onChange={handleInputChange}
                                            className="mr-2"
                                        />
                                        Tidak
                                    </label>
                                </div>
                            </div>

                            {/* Acak Jawaban */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Acak Jawaban
                                </label>
                                <div className="flex items-center space-x-4">
                                    <label>
                                        <input
                                            type="radio"
                                            name="acakJawaban"
                                            value="ya"
                                            checked={
                                                formData.acakJawaban === "ya"
                                            }
                                            onChange={handleInputChange}
                                            className="mr-2"
                                        />
                                        Ya
                                    </label>
                                    <label>
                                        <input
                                            type="radio"
                                            name="acakJawaban"
                                            value="tidak"
                                            checked={
                                                formData.acakJawaban === "tidak"
                                            }
                                            onChange={handleInputChange}
                                            className="mr-2"
                                        />
                                        Tidak
                                    </label>
                                </div>
                            </div>

                            {/* Petunjuk Pengerjaan */}
                            <div className="mb-4 col-span-2">
                                <label className="block text-sm font-medium text-gray-700">
                                    Petunjuk Pengerjaan
                                </label>
                                <ReactQuill
                                    value={formData.petunjukPengerjaan}
                                    onChange={handleQuillChange}
                                    className="mt-1"
                                    placeholder="Petunjuk pengerjaan"
                                    modules={{
                                        toolbar: [
                                            [{ header: [1, 2, false] }],
                                            [
                                                "bold",
                                                "italic",
                                                "underline",
                                                "strike",
                                                "blockquote",
                                            ],
                                            [
                                                { list: "ordered" },
                                                { list: "bullet" },
                                            ],
                                            ["link", "image"],
                                            ["clean"],
                                        ],
                                    }}
                                    formats={[
                                        "header",
                                        "bold",
                                        "italic",
                                        "underline",
                                        "strike",
                                        "blockquote",
                                        "list",
                                        "bullet",
                                        "link",
                                        "image",
                                    ]}
                                />
                            </div>
                        </div>{" "}
                    </form>
                    {/* Buttons */}
                    <div className="flex justify-between gap-2 px-6 p-3">
                        <Link
                            href="/lembaga/paketsoal"
                            className="flex items-center px-4 py-2 gap-2 bg-gray-500 hover:bg-gray-700 text-white rounded"
                        >
                            Kembali
                        </Link>
                        <button
                            type="submit"
                            className="flex items-center px-4 py-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                        >
                            Tambah Paket
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
}
