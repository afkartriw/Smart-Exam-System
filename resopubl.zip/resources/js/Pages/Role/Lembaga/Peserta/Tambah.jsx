import React, { useState } from "react";
import { Link, usePage } from "@inertiajs/react"; // Impor usePage dan Link
import Navbar from "@/Components/Lembaga/Navbar";

export default function TambahPeserta() {
    const { props } = usePage(); // Akses data halaman melalui usePage
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        permissions: [],
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handlePermissionChange = (permission) => {
        setFormData((prevData) => ({
            ...prevData,
            permissions: prevData.permissions.includes(permission)
                ? prevData.permissions.filter((p) => p !== permission)
                : [...prevData.permissions, permission],
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Kirim data ke backend menggunakan Inertia.post
        Inertia.post("/peserta/tambah", formData, {
            onSuccess: () => {
                // Redirect ke halaman data peserta setelah berhasil
                Inertia.visit("/data-peserta");
            },
        });
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Navbar />
            {/* Main Content */}
            <main className="max-w-3xl m-auto pt-20">
                {" "}
                <div className="bg-white rounded-lg shadow-md">
                    {" "}
                    <div className="p-3 px-6">
                        <h1 className="text-2xl font-bold text-blue-900">
                            TAMBAH PESERTA
                        </h1>
                    </div>
                    <form
                        onSubmit={handleSubmit}
                        className="border-y p-3 px-6 grid grid-cols-1 md:grid-cols-2 gap-4"
                    >
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Nama Peserta
                            </label>
                            <input
                                type="text"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                No Peserta
                            </label>
                            <input
                                type="text"
                                name="noPeserta"
                                value={formData.noPeserta}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Email
                            </label>
                            <input
                                type="email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Password
                            </label>
                            <input
                                type="password"
                                name="password"
                                value={formData.password}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Kelompok
                            </label>
                            <input
                                type="text"
                                name="kelompok"
                                value={formData.kelompok}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Tags
                            </label>
                            <input
                                type="text"
                                name="tags"
                                value={formData.tags}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                    </form>
                    <div className="flex justify-between gap-2 p-3 px-6">
                        <a
                            href="/lembaga/peserta"
                            className="flex items-center px-4 py-2 gap-2 bg-gray-500 hover:bg-gray-700 text-white rounded"
                        >
                            Kembali
                        </a>
                        <button
                            type="submit"
                            className="flex items-center px-4 py-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                        >
                            Tambah Peserta
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
}
