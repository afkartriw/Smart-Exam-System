import React, { useState } from "react";
import { Link, usePage } from "@inertiajs/react"; // Impor usePage, Link, dan Inertia
import { Inertia } from "@inertiajs/inertia"; // Import Inertia
import Navbar from "@/Components/Lembaga/Navbar";
import ReactQuill from "react-quill";
import "react-quill/dist/quill.snow.css"; // Import styles

export default function TambahPeserta() {
    const { props } = usePage(); // Akses data halaman melalui usePage
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        permissions: [],
        materi: "",
        acakSoal: "",
        acakJawaban: "",
        skalaNilai: 1,
        petunjukPengerjaan: "",
    });

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSkalaNilaiChange = (e) => {
        const newSkala = parseInt(e.target.value);
        setFormData((prev) => ({
            ...prev,
            skalaNilai: newSkala,
            kkm: prev.kkm > newSkala ? 1 : prev.kkm, // Reset KKM jika lebih besar dari skala baru
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        Inertia.post("/peserta/tambah", formData, {
            onSuccess: () => {
                Inertia.visit("/data-peserta");
            },
        });
    };

    const handleQuillChange = (value) => {
        setFormData({
            ...formData,
            petunjukPengerjaan: value,
        });
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Navbar />
            {/* Main Content */}
            <main className="max-w-3xl m-auto pt-20">
                <div className="bg-white rounded-xl shadow-xl">
                    {" "}
                    <div className="px-6 p-3">
                        <h1 className="text-2xl font-bold text-blue-900">
                            TAMBAH SESI UJIAN
                        </h1>
                    </div>
                    <form onSubmit={handleSubmit} className="px-6 p-3 border-y">
                        {/* Grid Layout */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            {/* Nama Sesi Ujian */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Nama Sesi Ujian
                                </label>
                                <input
                                    type="text"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Paket Soal */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Paket Soal
                                </label>
                                <input
                                    type="text"
                                    name="materi"
                                    value={formData.materi}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Mode Peserta */}
                            <div className="mb-4 ">
                                <label className="block text-sm font-medium text-gray-700">
                                    Mode Peserta
                                </label>
                                <div className="">
                                    {[
                                        "Semua",
                                        "Kelompok Peserta",
                                        "Gunakan Tags",
                                        "Manual",
                                    ].map((mode, i) => (
                                        <label
                                            key={i}
                                            className="flex items-center"
                                        >
                                            <input
                                                type="radio"
                                                name="modePeserta"
                                                value={mode}
                                                checked={
                                                    formData.modePeserta ===
                                                    mode
                                                }
                                                onChange={handleInputChange}
                                                className="mr-2"
                                            />
                                            {mode}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Tanggal Pelaksanaan */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Tanggal Pelaksanaan
                                </label>
                                <input
                                    type="date"
                                    name="tanggalPelaksanaan"
                                    value={formData.tanggalPelaksanaan}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Waktu Mulai */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Waktu Mulai
                                </label>
                                <input
                                    type="time"
                                    name="waktuMulai"
                                    value={formData.waktuMulai}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Waktu Pengerjaan */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Waktu Pengerjaan (Menit)
                                </label>
                                <input
                                    type="number"
                                    name="waktuPengerjaan"
                                    value={formData.waktuPengerjaan}
                                    onChange={handleInputChange}
                                    className="mt-1 p-2 border rounded w-full"
                                    required
                                />
                            </div>

                            {/* Wajibkan Kamera */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Wajibkan Kamera
                                </label>
                                <div className="flex items-center space-x-4">
                                    {["Ya", "Tidak"].map((option, i) => (
                                        <label
                                            key={i}
                                            className="flex items-center"
                                        >
                                            <input
                                                type="radio"
                                                name="wajibKamera"
                                                value={option.toLowerCase()}
                                                checked={
                                                    formData.wajibKamera ===
                                                    option.toLowerCase()
                                                }
                                                onChange={handleInputChange}
                                                className="mr-2"
                                            />
                                            {option}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Batasi Browser Peserta */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Batasi Browser Peserta
                                </label>
                                <div className="flex items-center space-x-4">
                                    {["Ya", "Tidak"].map((option, i) => (
                                        <label
                                            key={i}
                                            className="flex items-center"
                                        >
                                            <input
                                                type="radio"
                                                name="batasiBrowser"
                                                value={option.toLowerCase()}
                                                checked={
                                                    formData.batasiBrowser ===
                                                    option.toLowerCase()
                                                }
                                                onChange={handleInputChange}
                                                className="mr-2"
                                            />
                                            {option}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Tampilkan Hasil */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Tampilkan Hasil
                                </label>
                                <div className="flex items-center space-x-4">
                                    {["Ya", "Tidak"].map((option, i) => (
                                        <label
                                            key={i}
                                            className="flex items-center"
                                        >
                                            <input
                                                type="radio"
                                                name="tampilkanHasil"
                                                value={option.toLowerCase()}
                                                checked={
                                                    formData.tampilkanHasil ===
                                                    option.toLowerCase()
                                                }
                                                onChange={handleInputChange}
                                                className="mr-2"
                                            />
                                            {option}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Tampilkan Pembahasan */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Tampilkan Pembahasan
                                </label>
                                <div className="flex items-center space-x-4">
                                    {["Ya", "Tidak"].map((option, i) => (
                                        <label
                                            key={i}
                                            className="flex items-center"
                                        >
                                            <input
                                                type="radio"
                                                name="tampilkanPembahasan"
                                                value={option.toLowerCase()}
                                                checked={
                                                    formData.tampilkanPembahasan ===
                                                    option.toLowerCase()
                                                }
                                                onChange={handleInputChange}
                                                className="mr-2"
                                            />
                                            {option}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Gunakan Sertifikat */}
                            <div className="mb-4">
                                <label className="block text-sm font-medium text-gray-700">
                                    Gunakan Sertifikat
                                </label>
                                <div className="flex items-center space-x-4">
                                    {["Ya", "Tidak"].map((option, i) => (
                                        <label
                                            key={i}
                                            className="flex items-center"
                                        >
                                            <input
                                                type="radio"
                                                name="gunakanSertifikat"
                                                value={option.toLowerCase()}
                                                checked={
                                                    formData.gunakanSertifikat ===
                                                    option.toLowerCase()
                                                }
                                                onChange={handleInputChange}
                                                className="mr-2"
                                            />
                                            {option}
                                        </label>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </form>
                    {/* Buttons */}
                    <div className="flex justify-between gap-2 px-6 p-3">
                        <Link
                            href="/lembaga/sesi"
                            className="flex items-center px-4 py-2 gap-2 bg-gray-500 hover:bg-gray-700 text-white rounded"
                        >
                            Kembali
                        </Link>
                        <button
                            type="submit"
                            className="flex items-center px-4 py-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                        >
                            Tambah Paket
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
}
