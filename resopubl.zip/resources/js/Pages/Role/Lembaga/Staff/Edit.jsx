import React, { useState } from "react";
import { Link, usePage } from "@inertiajs/react"; // Impor usePage dan Link
import Navbar from "@/Components/Lembaga/Navbar";
import { FaBook, FaCalendarAlt, FaUsers } from "react-icons/fa";
import { GiCctvCamera } from "react-icons/gi";

export default function page() {
    const { props } = usePage(); // Akses data halaman melalui usePage
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        password: "",
        permissions: [],
    });

    const icons = {
        AP: <FaUsers />,
        PGJ: <FaBook />,
        POW: <FaCalendarAlt />,
        AL: <GiCctvCamera />,
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handlePermissionChange = (permission) => {
        setFormData((prevData) => ({
            ...prevData,
            permissions: prevData.permissions.includes(permission)
                ? prevData.permissions.filter((p) => p !== permission)
                : [...prevData.permissions, permission],
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Kirim data ke backend menggunakan Inertia.post
        Inertia.post("/staf/edit", formData, {
            onSuccess: () => {
                // Redirect ke halaman data staf setelah berhasil
                Inertia.visit("/data-staf");
            },
        });
    };

    return (
        <div className="min-h-screen bg-gray-100">
            <Navbar />
            {/* Main Content */}
            <main className="max-w-3xl m-auto pt-20">
                <form
                    onSubmit={handleSubmit}
                    className="bg-white  rounded-2xl shadow-md"
                >
                    {" "}
                    <h1 className="text-2xl font-bold px-6 py-3 text-blue-900">
                        EDIT STAFF
                    </h1>
                    <div className="border-y p-6">
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Nama Staf
                            </label>
                            <input
                                type="text"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Email
                            </label>
                            <input
                                type="text"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Password
                            </label>
                            <input
                                type="text"
                                name="password"
                                value={formData.password}
                                onChange={handleInputChange}
                                className="mt-1 p-2 border rounded w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium text-gray-700">
                                Kewenangan
                            </label>
                            <div className="flex gap-2 mt-2">
                                {["AP", "PGJ", "POW", "AL"].map(
                                    (permission) => (
                                        <button
                                            key={permission}
                                            type="button"
                                            onClick={() =>
                                                handlePermissionChange(
                                                    permission
                                                )
                                            }
                                            className={`px-3 py-1 rounded w-10 h-10 ${
                                                formData.permissions.includes(
                                                    permission
                                                )
                                                    ? "bg-green-500 text-white"
                                                    : "bg-gray-200 text-gray-700"
                                            }`}
                                        >
                                            {icons[permission]}
                                        </button>
                                    )
                                )}
                            </div>
                        </div>{" "}
                    </div>
                    <div className="flex justify-between gap-2 px-6 py-3">
                        <a
                            href="/lembaga/staff"
                            className="flex items-center px-4 py-2 gap-2 bg-gray-500 hover:bg-gray-700 text-white rounded"
                        >
                            Kembali
                        </a>
                        <button
                            type="submit"
                            className="flex items-center px-4 py-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                        >
                            Edit Staff
                        </button>
                    </div>
                </form>
            </main>
        </div>
    );
}
