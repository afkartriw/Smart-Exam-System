import Pagination from "@/Components/Layout/Pagination";
import Navbar from "@/Components/Lembaga/Navbar";
import Sidebar from "@/Components/Lembaga/Sidebar";
import React, { useState } from "react";
import { FaEdit, FaEye, FaFilter, FaTrashAlt } from "react-icons/fa";
import { MdAddCircle } from "react-icons/md";

export default function Page() {
    const [filter, setFilter] = useState("");
    const [entries, setEntries] = useState(5);
    const [currentPage, setCurrentPage] = useState(1);
    const [soals, setSoals] = useState([
        {
            id: 1,
            name: "UTS Backend",
            soal: "Backend",
            kelompok: "TIB 22",
            Waktu: "13.00-15.00",
            Tanggal: "2 Maret 2025",
        },
        {
            id: 2,
            name: "UAS MTK",
            soal: "MTK",
            kelompok: "TIB 22",
            Waktu: "09.00-11.00",
            Tanggal: "3 Maret 2025",
        },
        {
            id: 3,
            name: "Ulangan B. Jawa",
            soal: "B. Jawa",
            kelompok: "TIB 22",
            Waktu: "10.00-12.00",
            Tanggal: "4 Maret 2025",
        },
        {
            id: 4,
            name: "Ujian Agama",
            soal: "Agama",
            kelompok: "TIB 22",
            Waktu: "08.00-10.00",
            Tanggal: "5 Maret 2025",
        },
        {
            id: 5,
            name: "UAS Pemrograman",
            soal: "Pemrograman",
            kelompok: "TIB 22",
            Waktu: "13.00-15.00",
            Tanggal: "6 Maret 2025",
        },
        {
            id: 6,
            name: "UN MTK",
            soal: "MTK",
            kelompok: "TIB 22",
            Waktu: "11.00-13.00",
            Tanggal: "7 Maret 2025",
        },
    ]);

    const handleFilterChange = (e) => {
        setFilter(e.target.value);
        setCurrentPage(1); // Reset ke halaman pertama saat filter berubah
    };

    const handleEntriesChange = (e) => {
        setEntries(parseInt(e.target.value));
        setCurrentPage(1); // Reset ke halaman pertama saat jumlah entri berubah
    };

    const filteredSoals = soals.filter((sesi) => {
        const lowerCaseFilter = filter.toLowerCase();
        return (
            sesi.name.toLowerCase().includes(lowerCaseFilter) ||
            sesi.soal.toLowerCase().includes(lowerCaseFilter) ||
            sesi.kelompok.toLowerCase().includes(lowerCaseFilter)
        );
    });

    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const totalPages = Math.ceil(filteredSoals.length / entries);
    const startIndex = (currentPage - 1) * entries;
    const paginatedSoals = filteredSoals.slice(
        startIndex,
        startIndex + entries
    );

    const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPages) {
            setCurrentPage(newPage);
        }
    };

    return (
        <div className="relative flex h-screen">
            {/* Sidebar */}
            <Sidebar
                isSidebarOpen={isSidebarOpen}
                toggleSidebar={toggleSidebar}
            />

            {/* Content Wrapper */}
            <div
                className={`flex-1 flex flex-col ${
                    isSidebarOpen ? "ml-56" : "ml-16"
                } transition-all duration-300`}
            >
                {/* Navbar */}
                <Navbar toggleSidebar={toggleSidebar} />
                <main className="pt-20 p-6 bg-color-accent min-h-screen h-full bg-gray-200">
                    <div className="bg-white rounded-2xl">
                        <div className="p-3 px-6">
                            <h1 className="text-2xl font-bold text-blue-900">
                                TABEL SESI
                            </h1>
                        </div>
                        <div className="flex justify-between items-center p-3 px-6 border-y">
                            <div className="flex gap-4">
                                <a
                                    href="/lembaga/sesi/tambah"
                                    className="flex items-center px-4 p-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                                >
                                    <MdAddCircle />
                                    Tambah
                                </a>
                            </div>
                        </div>
                        <div className="flex justify-between items-center p-3 px-6">
                            <div>
                                <label className="flex items-center gap-2">
                                    Show
                                    <select
                                        className="p-1 border rounded w-12"
                                        value={entries}
                                        onChange={handleEntriesChange}
                                    >
                                        {[5, 10, 15].map((num) => (
                                            <option key={num} value={num}>
                                                {num}
                                            </option>
                                        ))}
                                    </select>
                                    entries
                                </label>
                            </div>
                            <div className="flex items-center">
                                <input
                                    type="text"
                                    placeholder="Filter..."
                                    value={filter}
                                    onChange={handleFilterChange}
                                    className="h-8 border rounded"
                                />
                                <button className="ml-2 p-2 bg-blue-500 text-white rounded">
                                    <FaFilter />
                                </button>
                            </div>
                        </div>
                        <div className="px-6 pb-3">
                            <table className="w-full border rounded">
                                <thead>
                                    <tr className="bg-blue-500 text-white">
                                        <th className="p-2 border">No.</th>
                                        <th className="p-2 border">
                                            Nama Sesi
                                        </th>
                                        <th className="p-2 border">
                                            Paket Soal
                                        </th>
                                        <th className="p-2 border">Kelompok</th>
                                        <th className="p-2 border">Waktu</th>
                                        <th className="p-2 border">Tanggal</th>
                                        <th className="p-2 border">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paginatedSoals.map((sesi, index) => (
                                        <tr
                                            key={sesi.id}
                                            className="hover:bg-gray-100 text-center"
                                        >
                                            <td className="p-2 border">
                                                {startIndex + index + 1}
                                            </td>
                                            <td className="p-2 border">
                                                {sesi.name}
                                            </td>
                                            <td className="p-2 border">
                                                {sesi.soal}
                                            </td>
                                            <td className="p-2 border">
                                                {sesi.kelompok}
                                            </td>
                                            <td className="p-2 border">
                                                {sesi.Waktu}
                                            </td>
                                            <td className="p-2 border">
                                                {sesi.Tanggal}
                                            </td>
                                            <td className="p-2 border">
                                                <div className="flex justify-center gap-2">
                                                    <button className="text-blue-500 hover:text-blue-700">
                                                        <FaEdit />
                                                    </button>
                                                    <button className="text-green-500 hover:text-green-700">
                                                        <FaEye />
                                                    </button>
                                                    <button className="text-red-500 hover:text-red-700">
                                                        <FaTrashAlt />
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                handlePageChange={handlePageChange}
                                startIndex={startIndex}
                                entries={entries}
                                filtered={filteredSoals}
                            />
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
