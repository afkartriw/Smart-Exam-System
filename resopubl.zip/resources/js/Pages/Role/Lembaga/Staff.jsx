import { Tooltip } from "react-tooltip";
import "react-tooltip/dist/react-tooltip.css";
import Pagination from "@/Components/Layout/Pagination";
import Navbar from "@/Components/Lembaga/Navbar";
import Sidebar from "@/Components/Lembaga/Sidebar";
import React, { useState } from "react";
import { FaEdit, FaFilter, FaTrashAlt, FaUsers } from "react-icons/fa";
import { FaBook, FaCalendarAlt } from "react-icons/fa";
import { GiCctvCamera } from "react-icons/gi";
import { MdAddCircle } from "react-icons/md";

export default function Page() {
    const [filter, setFilter] = useState("");
    const [entries, setEntries] = useState(5);
    const [currentPage, setCurrentPage] = useState(1);
    const [Staffs, setStaffs] = useState([
        {
            id: 1,
            name: "Seiyo Wahyudhi",
            email: "seiyowahyudhi_ksusb@yahoo.com",
            accessCode: "AL111",
            permissions: ["PESERTA", "PSOAL", "SESI"],
        },
        {
            id: 2,
            name: "Faridotun Hilaliyah",
            email: "lia@gmail.com",
            accessCode: "12345",
            permissions: ["PENGAWAS"],
        },
        {
            id: 3,
            name: "Budi Santoso",
            email: "budi@gmail.com",
            accessCode: "56789",
            permissions: ["PSOAL"],
        },
        {
            id: 4,
            name: "Siti Rahma",
            email: "rahma@gmail.com",
            accessCode: "POW111",
            permissions: ["SESI"],
        },
        {
            id: 5,
            name: "Ahmad Fauzi",
            email: "ahmad@gmail.com",
            accessCode: "AP222",
            permissions: ["PESERTA"],
        },
        {
            id: 6,
            name: "Nina Kartika",
            email: "nina@gmail.com",
            accessCode: "AL333",
            permissions: ["PENGAWAS"],
        },
    ]);

    const icons = {
        PESERTA: <FaUsers />,
        PSOAL: <FaBook />,
        SESI: <FaCalendarAlt />,
        PENGAWAS: <GiCctvCamera />,
    };

    const handleFilterChange = (e) => {
        setFilter(e.target.value);
        setCurrentPage(1); // Reset ke halaman pertama saat filter berubah
    };

    const handleEntriesChange = (e) => {
        setEntries(parseInt(e.target.value));
        setCurrentPage(1); // Reset ke halaman pertama saat jumlah entri berubah
    };

    const filtered = Staffs.filter((staff) => {
        const lowerCaseFilter = filter.toLowerCase();
        return (
            staff.name.toLowerCase().includes(lowerCaseFilter) ||
            staff.email.toLowerCase().includes(lowerCaseFilter) ||
            staff.accessCode.toLowerCase().includes(lowerCaseFilter)
        );
    });

    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };

    const totalPages = Math.ceil(filtered.length / entries);
    const startIndex = (currentPage - 1) * entries;
    const paginatedStaffs = filtered.slice(startIndex, startIndex + entries);

    const togglePermission = (staffId, permission) => {
        setStaffs((prevStaffs) =>
            prevStaffs.map((staff) =>
                staff.id === staffId
                    ? {
                          ...staff,
                          permissions: staff.permissions.includes(permission)
                              ? staff.permissions.filter(
                                    (p) => p !== permission
                                )
                              : [...staff.permissions, permission],
                      }
                    : staff
            )
        );
    };

    const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPages) {
            setCurrentPage(newPage);
        }
    };

    return (
        <div className="relative flex h-screen">
            {/* Sidebar */}
            <Sidebar
                isSidebarOpen={isSidebarOpen}
                toggleSidebar={toggleSidebar}
            />

            {/* Content Wrapper */}
            <div
                className={`flex-1 flex flex-col ${
                    isSidebarOpen ? "ml-56" : "ml-16"
                } transition-all duration-300`}
            >
                {/* Navbar */}
                <Navbar toggleSidebar={toggleSidebar} />{" "}
                <main className="pt-20 p-6 bg-color-accent min-h-screen h-full bg-gray-200">
                    <div className="bg-white rounded-2xl">
                        {" "}
                        <div className="p-3 px-6">
                            <h1 className="text-2xl font-bold text-blue-900">
                                TABEL STAFF
                            </h1>{" "}
                        </div>
                        <div className="flex justify-between items-center p-3 px-6 border-y">
                            <div className="flex gap-4">
                                <a
                                    href="/lembaga/staff/tambah"
                                    className="flex items-center px-4 p-2 gap-2 bg-green-500 hover:bg-green-700 text-white rounded"
                                >
                                    <MdAddCircle />
                                    Tambah
                                </a>
                            </div>
                        </div>
                        <div className="flex justify-between items-center p-3 px-6">
                            <div>
                                <label className="flex items-center gap-2">
                                    Show
                                    <select
                                        className="p-1 border rounded w-12"
                                        value={entries}
                                        onChange={handleEntriesChange}
                                    >
                                        {[5, 10, 15].map((num) => (
                                            <option key={num} value={num}>
                                                {num}
                                            </option>
                                        ))}
                                    </select>
                                    entries
                                </label>
                            </div>
                            <div className="flex items-center">
                                <input
                                    type="text"
                                    placeholder="Filter..."
                                    value={filter}
                                    onChange={handleFilterChange}
                                    className="h-8 border rounded"
                                />
                                <button className="ml-2 p-2 bg-blue-500 text-white rounded">
                                    <FaFilter />
                                </button>
                            </div>
                        </div>
                        <div className="px-6 pb-3">
                            <table className="w-full border rounded">
                                <thead>
                                    <tr className="bg-blue-500 text-white">
                                        <th className="p-2 border">No.</th>
                                        <th className="p-2 border">
                                            Nama Staff
                                        </th>
                                        <th className="p-2 border">Email</th>
                                        <th className="p-2 border">Password</th>
                                        <th className="p-2 border">
                                            Kewenangan
                                        </th>
                                        <th className="p-2 border">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paginatedStaffs.map((staff, index) => (
                                        <tr
                                            key={staff.id}
                                            className="hover:bg-gray-100"
                                        >
                                            <td className="p-2 border text-center">
                                                {index + 1}
                                            </td>
                                            <td className="p-2 border">
                                                {staff.name}
                                            </td>
                                            <td className="p-2 border">
                                                {staff.email}
                                            </td>
                                            <td className="p-2 border text-center">
                                                {staff.accessCode}
                                            </td>
                                            <td className="p-2 border">
                                                <div className="flex gap-3 justify-center">
                                                    {[
                                                        "PESERTA",
                                                        "PSOAL",
                                                        "SESI",
                                                        "PENGAWAS",
                                                    ].map((permission) => (
                                                        <button
                                                            key={permission}
                                                            onClick={() =>
                                                                togglePermission(
                                                                    staff.id,
                                                                    permission
                                                                )
                                                            }
                                                            className={`p-2 rounded flex items-center justify-center ${
                                                                staff.permissions.includes(
                                                                    permission
                                                                )
                                                                    ? "bg-green-500 text-white"
                                                                    : "bg-gray-200 text-gray-700"
                                                            }`}
                                                            data-tooltip-id={`tooltip-${permission}`}
                                                            data-tooltip-content={
                                                                permission
                                                            }
                                                        >
                                                            {icons[permission]}
                                                        </button>
                                                    ))}
                                                </div>

                                                {/* Tooltip Components */}
                                                {[
                                                    "PESERTA",
                                                    "PSOAL",
                                                    "SESI",
                                                    "PENGAWAS",
                                                ].map((permission) => (
                                                    <Tooltip
                                                        key={permission}
                                                        id={`tooltip-${permission}`}
                                                    />
                                                ))}
                                            </td>
                                            <td className="p-2 border">
                                                <div className="flex gap-4 justify-center">
                                                    {" "}
                                                    <a
                                                        href="/lembaga/staff/edit"
                                                        className="text-blue-500"
                                                        data-tooltip-id="edit-tooltip"
                                                        data-tooltip-content="Edit"
                                                    >
                                                        <FaEdit />{" "}
                                                    </a>{" "}
                                                    <button
                                                        data-tooltip-id="delete-tooltip"
                                                        data-tooltip-content="Hapus"
                                                    >
                                                        <FaTrashAlt color="red" />
                                                    </button>
                                                </div>
                                                {/* Tooltip Components */}
                                                <Tooltip id="edit-tooltip" />
                                                <Tooltip id="detail-tooltip" />
                                                <Tooltip id="delete-tooltip" />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>{" "}
                            <Pagination
                                currentPage={currentPage}
                                totalPages={totalPages}
                                handlePageChange={handlePageChange}
                                startIndex={startIndex}
                                entries={entries}
                                filtered={filtered}
                            />
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
