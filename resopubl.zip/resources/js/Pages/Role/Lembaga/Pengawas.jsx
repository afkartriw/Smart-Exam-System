import Navbar from "@/Components/Lembaga/Navbar";
import Sidebar from "@/Components/Lembaga/Sidebar";
import React, { useState } from "react";

export default function Page() {
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    const toggleSidebar = () => {
        setIsSidebarOpen(!isSidebarOpen);
    };
    const [customPoin, setCustomPoin] = useState("");

    const paketPoin = [
        { nama: "Amarilis", poin: 100, harga: 112500 },
        { nama: "Bouvardia", poin: 250, harga: 262500 },
        { nama: "Cranberry", poin: 500, harga: 487500 },
        { nama: "Daffodil", poin: 750, harga: 675000 },
        { nama: "Euphorbia", poin: 1000, harga: 825000 },
    ];

    return (
        <div className="relative flex h-screen">
            {/* Sidebar */}
            <Sidebar
                isSidebarOpen={isSidebarOpen}
                toggleSidebar={toggleSidebar}
            />

            {/* Content Wrapper */}
            <div
                className={`flex-1 flex flex-col ${
                    isSidebarOpen ? "ml-56" : "ml-16"
                } transition-all duration-300`}
            >
                {/* Navbar */}
                <Navbar toggleSidebar={toggleSidebar} />{" "}
                <main className="pt-20 p-6 bg-color-accent min-h-screen h-full bg-gray-200">
                    <div className="bg-white rounded-2xl">
                        {" "}
                        <div className="border-b p-3 px-6">
                            <h1 className="text-2xl text-blue-900 font-bold">
                                PENGAWASAN UJIAN
                            </h1>
                        </div>
                        <div className="px-6 p-3">
                            <h1 className="text-xl font-bold">
                                Ujian yang sedang berlangsung
                            </h1>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-8">
                            {/* Uji Kompetensi #1 */}
                            <div className="border p-4 rounded shadow-sm bg-white">
                                <h3 className="font-semibold">
                                    Uji Kompetensi #1
                                </h3>
                                <p className="text-blue-600 font-medium">
                                    Bahasa Indonesia
                                </p>
                                <p>Mulai: Senin, 02 Agt 2021 17:45:00</p>
                                <p>Sifat: Serentak</p>
                                <p>Durasi: 120 menit</p>
                                <p>Batas: Senin, 02 Agt 2021 19:45:00</p>
                                <div className="mt-4 flex items-center">
                                    <button className="bg-green-500 text-white px-3 py-1 rounded">
                                        Masuk
                                    </button>
                                </div>
                            </div>
                            <div className="border p-4 rounded shadow-sm bg-white">
                                <h3 className="font-semibold">
                                    Uji Kompetensi #1
                                </h3>
                                <p className="text-blue-600 font-medium">
                                    Bahasa Indonesia
                                </p>
                                <p>Mulai: Senin, 02 Agt 2021 17:45:00</p>
                                <p>Sifat: Serentak</p>
                                <p>Durasi: 120 menit</p>
                                <p>Batas: Senin, 02 Agt 2021 19:45:00</p>
                                <div className="mt-4 flex items-center">
                                    <button className="bg-green-500 text-white px-3 py-1 rounded">
                                        Masuk
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}
