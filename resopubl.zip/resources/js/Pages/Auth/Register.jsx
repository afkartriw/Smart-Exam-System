import React from "react";
import Swal from "sweetalert2";
import { usePage } from "@inertiajs/react";
import Navbar from "@/Components/Layout/NavbarAuth";

const Konfirmasi = () => {
    const { url } = usePage();

    const handleFormSubmit = (e) => {
        e.preventDefault(); // Mencegah reload halaman
        Swal.fire({
            title: "Apakah Anda yakin?",
            text: "Data yang telah Anda masukkan akan dikirimkan!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Ya, kirimkan!",
            cancelButtonText: "Batal",
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    title: "Terkirim!",
                    text: "Data Anda berhasil dikirim.",
                    icon: "success",
                }).then(() => {
                    window.location.href = `/login`; // Navigasi ke /login
                });
            }
        });
    };

    return (
        <div className="min-h-screen bg-1 flex flex-col items-center justify-center">
            <Navbar />
            <div className="bg-white border w-full max-w-3xl rounded-2xl shadow-xl p-6 my-6 mt-20">
                <h1 className="text-2xl font-semibold text-gray-700 mb-4 border-b">
                    Pendaftaran Lembaga
                </h1>
                <form onSubmit={handleFormSubmit}>
                    <div className="mb-4">
                        <label
                            htmlFor="nama-lembaga"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Nama Lembaga
                        </label>
                        <input
                            type="text"
                            id="nama-lembaga"
                            placeholder="Ex: SMA Negeri 2 Purworejo"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>
                    <div className="mb-4">
                        <label
                            htmlFor="alamat-lembaga"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Alamat Lembaga
                        </label>
                        <input
                            type="text"
                            id="alamat-lembaga"
                            placeholder="Ex: Jl. Tentara Pelajar No. 78"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>
                    <div className="mb-4">
                        <label
                            htmlFor="kabupaten"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Kabupaten/Kota
                        </label>
                        <select
                            id="kabupaten"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="">Pilih</option>
                            <option value="kab1">Kabupaten 1</option>
                            <option value="kab2">Kabupaten 2</option>
                        </select>
                    </div>
                    <div className="mb-4">
                        <label
                            htmlFor="jenis-lembaga"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Jenis Lembaga
                        </label>
                        <select
                            id="jenis-lembaga"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        >
                            <option value="SD">SD/Sederajat</option>
                            <option value="SMP">SMP/Sederajat</option>
                            <option value="SMA">SMA/Sederajat</option>
                        </select>
                    </div>
                    <div className="bg-blue-100 p-4 rounded-md mb-4">
                        <h2 className="text-sm font-semibold text-blue-600 mb-2">
                            Informasi
                        </h2>
                        <p className="text-sm text-gray-700">
                            Lembaga Anda akan mendapatkan alamat URL pribadi
                            dengan format:{" "}
                            <span className="font-medium">
                                https://www.e-ujian.com/&#123;username_lembaga&#125;
                            </span>
                        </p>
                        <p className="text-sm text-gray-700 mt-2">
                            Silakan tentukan username tersebut di sini dengan
                            penuh pertimbangan, karena isian tersebut tidak
                            dapat diubah untuk seterusnya.
                        </p>
                        <p className="text-sm text-gray-700 mt-2">
                            <strong>Contoh username:</strong> sman2purworejo,
                            smkn1_banyuwangi, dsb.
                        </p>
                    </div>
                    <div className="mb-4">
                        <label
                            htmlFor="username-lembaga"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Username Lembaga
                        </label>
                        <input
                            type="text"
                            id="username-lembaga"
                            placeholder="Hanya huruf, angka, atau _"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>

                    <div className="my-6 mt-10">
                        <h2 className="text-2xl font-semibold text-gray-700 mb-4 border-b">
                            Data Pribadi Anda
                        </h2>
                    </div>

                    <div className="mb-4">
                        <label
                            htmlFor="email"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Alamat Email
                        </label>
                        <input
                            type="email"
                            id="email"
                            placeholder="Email valid dan aktif"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>
                    <div className="mb-4">
                        <label
                            htmlFor="nama-lengkap"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Nama Lengkap
                        </label>
                        <input
                            type="text"
                            id="nama-lengkap"
                            placeholder="tanpa gelar"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>
                    <div className="mb-4">
                        <label
                            htmlFor="whatsapp"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Nomor WhatsApp
                        </label>
                        <input
                            type="tel"
                            id="whatsapp"
                            placeholder="Nomor WhatsApp valid"
                            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        />
                    </div>

                    {/* CAPTCHA Section */}
                    <div className="mb-4">
                        <label
                            htmlFor="captcha"
                            className="block text-sm font-medium text-gray-600"
                        >
                            Masukkan CAPTCHA
                        </label>
                        <div className="flex items-center">
                            <img
                                src="https://via.placeholder.com/150x50.png?text=CAPTCHA"
                                alt="CAPTCHA"
                                className="mr-4"
                            />
                        </div>
                        <div className="flex items-center">
                            <input
                                type="text"
                                id="captcha"
                                placeholder="Masukkan kode CAPTCHA"
                                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            />
                        </div>
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:ring-2 focus:ring-blue-300"
                    >
                        Daftar
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Konfirmasi;
