import React from "react";

const Pagination = ({
    currentPage,
    totalPages,
    handlePageChange,
    startIndex,
    entries,
    filtered,
}) => {
    return (
        <div className="flex justify-between items-center mt-4 p-2">
            <p>
                Showing {startIndex + 1} to{" "}
                {Math.min(startIndex + entries, filtered.length)} of{" "}
                {filtered.length} entries
            </p>
            <div className="flex gap-2">
                <button
                    className="px-4 py-2 border rounded disabled:opacity-50 hover:bg-gray-100 transition duration-300"
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                >
                    Prev
                </button>
                <button
                    className="px-4 py-2 border rounded disabled:opacity-50 hover:bg-gray-100 transition duration-300"
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default Pagination;